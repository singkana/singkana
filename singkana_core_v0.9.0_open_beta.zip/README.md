# SingKANA β-フィードバック版 – VPS 展開パッケージ

このパッケージは、ConoHa などの Linux VPS 上でそのまま展開して動かせる
「無料配布 β フィードバック版 SingKANA」用の最小構成です。

## 同梱ファイル

- `app_web.py` : Flask アプリ本体（`/api/convert`, `/api/feedback`, `/health`）
- `singkana_engine.py` : OpenAI API を使った歌詞かな変換エンジン
- `index.html` : βテスター向け UI（歌詞入力 + プレビュー + フィードバック欄）
- `requirements.txt` : 必要な Python ライブラリ
- `.env.example` : 環境変数サンプル
- `log/` : アプリ・フィードバックログ出力先

## ローカル動作確認

```bash
python -m venv .venv
source .venv/bin/activate  # Windows は .venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# .env を編集して OPENAI_API_KEY を設定

python app_web.py
```

ブラウザで `http://127.0.0.1:5000` を開き、英語歌詞を貼り付けてテストしてください。

## VPS への基本配置例

1. `/srv/singkana` などのディレクトリにこの zip を展開
2. 上記と同様に venv + `pip install -r requirements.txt`
3. `.env` に `OPENAI_API_KEY` を設定
4. `gunicorn -w 3 -b 127.0.0.1:8000 app_web:app` で起動
5. nginx から `http(s)://your-domain` → `127.0.0.1:8000` へリバースプロキシ
